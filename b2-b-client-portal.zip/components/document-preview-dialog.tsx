import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"

interface DocumentPreviewDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  document: {
    _id: string
    document_type: string
    document_section: string
    state: string
    url: string
    createdAt: string
  }
}

export function DocumentPreviewDialog({ open, onOpenChange, document }: DocumentPreviewDialogProps) {
  const isPDF = document.url.toLowerCase().endsWith(".pdf")

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <div className="flex items-start justify-between gap-4">
            <div>
              <DialogTitle>{document.document_type}</DialogTitle>
              <DialogDescription>{document.document_section}</DialogDescription>
            </div>
            <Badge>{document.state}</Badge>
          </div>
        </DialogHeader>
        <div className="flex-1 min-h-0 overflow-hidden">
          {isPDF ? (
            <iframe
              src={document.url}
              className="w-full h-full min-h-[500px] rounded-md border"
              title="Document Preview"
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full gap-4 p-8">
              <p className="text-muted-foreground text-center">Vista previa no disponible para este tipo de archivo</p>
              <Button asChild>
                <a href={document.url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Abrir en nueva pestaña
                </a>
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
