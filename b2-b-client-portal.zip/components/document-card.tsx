"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Eye, FileText } from "lucide-react"
import { useState } from "react"
import { DocumentPreviewDialog } from "./document-preview-dialog"

interface DocumentCardProps {
  document: {
    _id: string
    document_type: string
    document_section: string
    state: string
    url: string
    createdAt: string
  }
}

export function DocumentCard({ document }: DocumentCardProps) {
  const [showPreview, setShowPreview] = useState(false)

  const handleDownload = () => {
    window.open(document.url, "_blank")
  }

  const getStateColor = (state: string) => {
    const stateMap: Record<string, string> = {
      aprobado: "bg-green-500/10 text-green-500 hover:bg-green-500/20",
      pendiente: "bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20",
      rechazado: "bg-red-500/10 text-red-500 hover:bg-red-500/20",
    }
    return stateMap[state.toLowerCase()] || "bg-muted text-muted-foreground"
  }

  return (
    <>
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3 flex-1">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <CardTitle className="text-lg">{document.document_type}</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">{document.document_section}</p>
              </div>
            </div>
            <Badge className={getStateColor(document.state)}>{document.state}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowPreview(true)} className="flex-1">
              <Eye className="mr-2 h-4 w-4" />
              Previsualizar
            </Button>
            <Button variant="default" size="sm" onClick={handleDownload} className="flex-1">
              <Download className="mr-2 h-4 w-4" />
              Descargar
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            Creado: {new Date(document.createdAt).toLocaleDateString("es-ES")}
          </p>
        </CardContent>
      </Card>

      <DocumentPreviewDialog open={showPreview} onOpenChange={setShowPreview} document={document} />
    </>
  )
}
