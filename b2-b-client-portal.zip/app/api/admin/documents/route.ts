import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import connectDB from "@/lib/db"
import DocumentModel from "@/models/Document"

export async function GET() {
  try {
    const session = await getSession()

    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    await connectDB()

    const documents = await DocumentModel.find().populate("user_id", "name email").sort({ createdAt: -1 })

    return NextResponse.json({ documents })
  } catch (error) {
    console.error("Get documents error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getSession()

    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { user_id, document_type, document_section, state, url } = await request.json()

    if (!user_id || !document_type || !document_section || !state || !url) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    await connectDB()

    const document = await DocumentModel.create({
      user_id,
      document_type,
      document_section,
      state,
      url,
    })

    return NextResponse.json({
      success: true,
      document,
    })
  } catch (error) {
    console.error("Create document error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
