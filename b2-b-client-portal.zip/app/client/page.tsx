import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import connectDB from "@/lib/db"
import User from "@/models/User"
import DocumentModel from "@/models/Document"
import { ClientHeader } from "@/components/client-header"
import { DocumentCard } from "@/components/document-card"
import { FileText } from "lucide-react"

export default async function ClientPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  if (session.role !== "client") {
    redirect("/admin")
  }

  await connectDB()

  const user = await User.findById(session.userId)
  const documents = await DocumentModel.find({ user_id: session.userId }).sort({ createdAt: -1 }).lean()

  const serializedDocuments = documents.map((doc) => ({
    _id: doc._id.toString(),
    document_type: doc.document_type,
    document_section: doc.document_section,
    state: doc.state,
    url: doc.url,
    createdAt: doc.createdAt.toISOString(),
  }))

  return (
    <div className="min-h-screen bg-muted/30">
      <ClientHeader userName={user?.name || "Usuario"} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-2">Mis Documentos</h2>
          <p className="text-muted-foreground">Aquí encontrarás todos tus documentos disponibles</p>
        </div>

        {serializedDocuments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="p-4 rounded-full bg-muted mb-4">
              <FileText className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No hay documentos</h3>
            <p className="text-muted-foreground max-w-md">
              Aún no tienes documentos disponibles. Cuando se agreguen nuevos documentos, aparecerán aquí.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {serializedDocuments.map((doc) => (
              <DocumentCard key={doc._id} document={doc} />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
