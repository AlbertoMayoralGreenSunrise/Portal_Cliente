import connectDB from "@/lib/db"
import DocumentModel from "@/models/Document"
import { CreateDocumentDialog } from "@/components/create-document-dialog"
import { EditDocumentDialog } from "@/components/edit-document-dialog"
import { DeleteDocumentDialog } from "@/components/delete-document-dialog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default async function DocumentsPage() {
  await connectDB()

  const documents = await DocumentModel.find().populate("user_id", "name email").sort({ createdAt: -1 }).lean()

  const serializedDocuments = documents.map((doc: any) => ({
    _id: doc._id.toString(),
    document_type: doc.document_type,
    document_section: doc.document_section,
    state: doc.state,
    url: doc.url,
    createdAt: doc.createdAt.toISOString(),
    userName: doc.user_id?.name || "Usuario desconocido",
    userEmail: doc.user_id?.email || "",
  }))

  const getStateColor = (state: string) => {
    const stateMap: Record<string, string> = {
      aprobado: "bg-green-500/10 text-green-500",
      pendiente: "bg-yellow-500/10 text-yellow-500",
      rechazado: "bg-red-500/10 text-red-500",
    }
    return stateMap[state.toLowerCase()] || "bg-muted text-muted-foreground"
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Gestión de Documentos</h1>
          <p className="text-muted-foreground">Administra los documentos de todos los usuarios</p>
        </div>
        <CreateDocumentDialog />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Documentos</CardTitle>
          <CardDescription>Total de documentos: {serializedDocuments.length}</CardDescription>
        </CardHeader>
        <CardContent>
          {serializedDocuments.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No hay documentos registrados</p>
          ) : (
            <div className="space-y-4">
              {serializedDocuments.map((doc) => (
                <div
                  key={doc._id}
                  className="flex items-start justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors gap-4"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold">{doc.document_type}</h3>
                      <Badge className={getStateColor(doc.state)}>{doc.state}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">Sección: {doc.document_section}</p>
                    <p className="text-sm text-muted-foreground">
                      Usuario: {doc.userName} ({doc.userEmail})
                    </p>
                    <a
                      href={doc.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-primary hover:underline inline-block mt-1"
                    >
                      Ver documento
                    </a>
                    <p className="text-xs text-muted-foreground mt-1">
                      Creado: {new Date(doc.createdAt).toLocaleDateString("es-ES")}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <EditDocumentDialog
                      document={{
                        _id: doc._id,
                        document_type: doc.document_type,
                        document_section: doc.document_section,
                        state: doc.state,
                        url: doc.url,
                      }}
                    />
                    <DeleteDocumentDialog documentId={doc._id} documentType={doc.document_type} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
