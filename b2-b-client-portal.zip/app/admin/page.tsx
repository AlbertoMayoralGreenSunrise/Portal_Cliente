import { getSession } from "@/lib/auth"
import connectDB from "@/lib/db"
import User from "@/models/User"
import DocumentModel from "@/models/Document"
import { StatCard } from "@/components/stat-card"
import { Users, FileText, CheckCircle, Clock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default async function AdminDashboardPage() {
  const session = await getSession()

  await connectDB()

  const totalClients = await User.countDocuments({ role: "client" })
  const totalDocuments = await DocumentModel.countDocuments()
  const approvedDocuments = await DocumentModel.countDocuments({ state: "aprobado" })
  const pendingDocuments = await DocumentModel.countDocuments({ state: "pendiente" })

  const recentDocuments = await DocumentModel.find()
    .sort({ createdAt: -1 })
    .limit(5)
    .populate("user_id", "name email")
    .lean()

  const serializedDocuments = recentDocuments.map((doc: any) => ({
    _id: doc._id.toString(),
    document_type: doc.document_type,
    state: doc.state,
    createdAt: doc.createdAt.toISOString(),
    userName: doc.user_id?.name || "Usuario desconocido",
  }))

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Bienvenido al panel de administración</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="Total Clientes" value={totalClients} icon={Users} description="Usuarios registrados" />
        <StatCard title="Total Documentos" value={totalDocuments} icon={FileText} description="En el sistema" />
        <StatCard
          title="Documentos Aprobados"
          value={approvedDocuments}
          icon={CheckCircle}
          description="Estado aprobado"
        />
        <StatCard
          title="Documentos Pendientes"
          value={pendingDocuments}
          icon={Clock}
          description="Requieren revisión"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Documentos Recientes</CardTitle>
          <CardDescription>Los últimos 5 documentos agregados al sistema</CardDescription>
        </CardHeader>
        <CardContent>
          {serializedDocuments.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No hay documentos recientes</p>
          ) : (
            <div className="space-y-4">
              {serializedDocuments.map((doc) => (
                <div
                  key={doc._id}
                  className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div>
                    <p className="font-medium">{doc.document_type}</p>
                    <p className="text-sm text-muted-foreground">{doc.userName}</p>
                  </div>
                  <div className="text-right">
                    <span
                      className={cn(
                        "text-xs px-2 py-1 rounded-full",
                        doc.state === "aprobado" && "bg-green-500/10 text-green-500",
                        doc.state === "pendiente" && "bg-yellow-500/10 text-yellow-500",
                        doc.state === "rechazado" && "bg-red-500/10 text-red-500",
                      )}
                    >
                      {doc.state}
                    </span>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(doc.createdAt).toLocaleDateString("es-ES")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(" ")
}
