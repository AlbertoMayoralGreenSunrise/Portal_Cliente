import mongoose, { type Document as MongooseDocument, type Model } from "mongoose"

export interface IDocument extends MongooseDocument {
  _id: mongoose.Types.ObjectId
  user_id: mongoose.Types.ObjectId
  document_type: string
  document_section: string
  state: string
  url: string
  createdAt: Date
  updatedAt: Date
}

const DocumentSchema = new mongoose.Schema<IDocument>(
  {
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Please provide a user ID"],
    },
    document_type: {
      type: String,
      required: [true, "Please provide a document type"],
      trim: true,
    },
    document_section: {
      type: String,
      required: [true, "Please provide a document section"],
      trim: true,
    },
    state: {
      type: String,
      required: [true, "Please provide a state"],
      trim: true,
    },
    url: {
      type: String,
      required: [true, "Please provide a URL"],
      trim: true,
    },
  },
  {
    timestamps: true,
  },
)

const DocumentModel: Model<IDocument> =
  mongoose.models.Document || mongoose.model<IDocument>("Document", DocumentSchema)

export default DocumentModel
